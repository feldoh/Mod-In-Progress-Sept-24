This is my first attempt at a mod.

I am attempting to create fertility drugs and birth control at Tribal, Industrial, and Spacer levels of technology.

